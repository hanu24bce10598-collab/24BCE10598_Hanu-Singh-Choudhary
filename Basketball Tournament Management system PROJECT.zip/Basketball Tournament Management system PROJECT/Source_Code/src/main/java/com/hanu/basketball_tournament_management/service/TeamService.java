package com.hanu.basketball_tournament_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanu.basketball_tournament_management.model.Team;
import com.hanu.basketball_tournament_management.repository.TeamRepository;

@Service
public class TeamService {

    @Autowired
    private TeamRepository teamRepository;

    public Team saveTeam(Team team) {
        return teamRepository.save(team);
    }

    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    public Team getTeamById(String id) {
        return teamRepository.findById(id).orElse(null);
    }

    public Team updateTeam(String id, Team team) {

        Team existingTeam = teamRepository.findById(id).orElse(null);

        if (existingTeam != null) {
            existingTeam.setTeamName(team.getTeamName());
            existingTeam.setCoachName(team.getCoachName());
            existingTeam.setCity(team.getCity());

            return teamRepository.save(existingTeam);
        }

        return null;
    }

    public void deleteTeam(String id) {
        teamRepository.deleteById(id);
    }
}