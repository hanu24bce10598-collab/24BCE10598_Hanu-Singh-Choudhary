package com.hanu.basketball_tournament_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hanu.basketball_tournament_management.model.Leaderboard;
import com.hanu.basketball_tournament_management.service.LeaderboardService;

@RestController
@RequestMapping("/leaderboards")
public class LeaderboardController {

    @Autowired
    private LeaderboardService leaderboardService;

    @PostMapping
    public Leaderboard saveLeaderboard(
            @RequestBody Leaderboard leaderboard) {

        return leaderboardService.saveLeaderboard(leaderboard);
    }

    @GetMapping
    public List<Leaderboard> getAllLeaderboards() {
        return leaderboardService.getAllLeaderboards();
    }

    @GetMapping("/{id}")
    public Leaderboard getLeaderboardById(
            @PathVariable String id) {

        return leaderboardService.getLeaderboardById(id);
    }

    @PutMapping("/{id}")
    public Leaderboard updateLeaderboard(
            @PathVariable String id,
            @RequestBody Leaderboard leaderboard) {

        return leaderboardService.updateLeaderboard(id, leaderboard);
    }

    @DeleteMapping("/{id}")
    public String deleteLeaderboard(
            @PathVariable String id) {

        leaderboardService.deleteLeaderboard(id);

        return "Leaderboard Deleted Successfully";
    }
}