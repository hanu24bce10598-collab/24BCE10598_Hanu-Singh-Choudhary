package com.hanu.basketball_tournament_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "leaderboard")
public class Leaderboard {

    @Id
    private String id;

    private String teamName;
    private int wins;
    private int losses;
    private int points;

    public Leaderboard() {
    }

    public Leaderboard(String id, String teamName,
                       int wins, int losses, int points) {
        this.id = id;
        this.teamName = teamName;
        this.wins = wins;
        this.losses = losses;
        this.points = points;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    @Override
public String toString() {
    return "Leaderboard{" +
            "id='" + id + '\'' +
            ", teamName='" + teamName + '\'' +
            ", wins=" + wins +
            ", losses=" + losses +
            ", points=" + points +
            '}';
}
}