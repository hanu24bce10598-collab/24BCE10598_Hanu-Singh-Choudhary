package com.hanu.basketball_tournament_management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hanu.basketball_tournament_management.model.Match;
import com.hanu.basketball_tournament_management.service.MatchService;

@RestController
@RequestMapping("/matches")
public class MatchController {

    @Autowired
    private MatchService matchService;

    @PostMapping
    public Match saveMatch(@RequestBody Match match) {
        return matchService.saveMatch(match);
    }

    @GetMapping
    public List<Match> getAllMatches() {
        return matchService.getAllMatches();
    }

    @GetMapping("/{id}")
    public Match getMatchById(@PathVariable String id) {
        return matchService.getMatchById(id);
    }

    @PutMapping("/{id}")
    public Match updateMatch(
            @PathVariable String id,
            @RequestBody Match match) {

        return matchService.updateMatch(id, match);
    }

    @DeleteMapping("/{id}")
    public String deleteMatch(@PathVariable String id) {

        matchService.deleteMatch(id);

        return "Match Deleted Successfully";
    }
}