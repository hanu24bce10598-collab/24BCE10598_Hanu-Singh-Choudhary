package com.hanu.basketball_tournament_management;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.hanu.basketball_tournament_management.repository.TeamRepository;
import com.hanu.basketball_tournament_management.repository.PlayerRepository;
import com.hanu.basketball_tournament_management.repository.MatchRepository;
import com.hanu.basketball_tournament_management.repository.LeaderboardRepository;

@Component
public class ConsoleRunner implements CommandLineRunner {

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private MatchRepository matchRepository;

    @Autowired
    private LeaderboardRepository leaderboardRepository;

    @Override
    public void run(String... args) throws Exception {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n=================================");
            System.out.println(" BASKETBALL TOURNAMENT SYSTEM ");
            System.out.println("=================================");
            System.out.println("1. View Teams");
            System.out.println("2. View Players");
            System.out.println("3. View Matches");
            System.out.println("4. View Leaderboard");
            System.out.println("5. Exit");
            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.println("\n------ TEAMS ------");
                    teamRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 2:
                    System.out.println("\n------ PLAYERS ------");
                    playerRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 3:
                    System.out.println("\n------ MATCHES ------");
                    matchRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 4:
                    System.out.println("\n------ LEADERBOARD ------");
                    leaderboardRepository.findAll()
                            .forEach(System.out::println);
                    break;

                case 5:
                    System.out.println("Exiting System...");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}