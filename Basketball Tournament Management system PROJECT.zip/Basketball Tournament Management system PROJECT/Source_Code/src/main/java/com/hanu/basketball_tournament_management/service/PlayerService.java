package com.hanu.basketball_tournament_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanu.basketball_tournament_management.model.Player;
import com.hanu.basketball_tournament_management.repository.PlayerRepository;

@Service
public class PlayerService {

    @Autowired
    private PlayerRepository playerRepository;

    public Player savePlayer(Player player) {
        return playerRepository.save(player);
    }

    public List<Player> getAllPlayers() {
        return playerRepository.findAll();
    }

    public Player getPlayerById(String id) {
        return playerRepository.findById(id).orElse(null);
    }

    public Player updatePlayer(String id, Player player) {

        Player existingPlayer = playerRepository.findById(id).orElse(null);

        if (existingPlayer != null) {
            existingPlayer.setPlayerName(player.getPlayerName());
            existingPlayer.setJerseyNumber(player.getJerseyNumber());
            existingPlayer.setPosition(player.getPosition());
            existingPlayer.setTeamName(player.getTeamName());

            return playerRepository.save(existingPlayer);
        }

        return null;
    }

    public void deletePlayer(String id) {
        playerRepository.deleteById(id);
    }
}