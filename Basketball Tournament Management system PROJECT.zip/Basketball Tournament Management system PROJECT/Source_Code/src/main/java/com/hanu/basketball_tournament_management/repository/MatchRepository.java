package com.hanu.basketball_tournament_management.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.hanu.basketball_tournament_management.model.Match;

public interface MatchRepository extends MongoRepository<Match, String> {

}