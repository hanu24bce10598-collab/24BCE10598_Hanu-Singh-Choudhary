package com.hanu.basketball_tournament_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasketballTournamentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasketballTournamentManagementApplication.class, args);
	}

}
