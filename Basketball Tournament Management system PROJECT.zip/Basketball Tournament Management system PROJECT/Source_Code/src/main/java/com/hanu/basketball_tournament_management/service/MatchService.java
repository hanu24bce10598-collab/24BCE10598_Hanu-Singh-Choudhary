package com.hanu.basketball_tournament_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanu.basketball_tournament_management.model.Match;
import com.hanu.basketball_tournament_management.repository.MatchRepository;

@Service
public class MatchService {

    @Autowired
    private MatchRepository matchRepository;

    public Match saveMatch(Match match) {
        return matchRepository.save(match);
    }

    public List<Match> getAllMatches() {
        return matchRepository.findAll();
    }

    public Match getMatchById(String id) {
        return matchRepository.findById(id).orElse(null);
    }

    public Match updateMatch(String id, Match match) {

        Match existingMatch = matchRepository.findById(id).orElse(null);

        if (existingMatch != null) {

            existingMatch.setTeam1(match.getTeam1());
            existingMatch.setTeam2(match.getTeam2());
            existingMatch.setScore1(match.getScore1());
            existingMatch.setScore2(match.getScore2());
            existingMatch.setWinner(match.getWinner());

            return matchRepository.save(existingMatch);
        }

        return null;
    }

    public void deleteMatch(String id) {
        matchRepository.deleteById(id);
    }
}