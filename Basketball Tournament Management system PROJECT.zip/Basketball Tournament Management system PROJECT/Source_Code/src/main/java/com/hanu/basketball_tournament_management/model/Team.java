package com.hanu.basketball_tournament_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "teams")
public class Team {

    @Id
    private String id;

    private String teamName;
    private String coachName;
    private String city;

    public Team() {
    }

    public Team(String id, String teamName, String coachName, String city) {
        this.id = id;
        this.teamName = teamName;
        this.coachName = coachName;
        this.city = city;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getCoachName() {
        return coachName;
    }

    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

@Override
public String toString() {
    return "Team{" +
            "id='" + id + '\'' +
            ", teamName='" + teamName + '\'' +
            ", coachName='" + coachName + '\'' +
            ", city='" + city + '\'' +
            '}';
}
}