package com.hanu.basketball_tournament_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "players")
public class Player {

    @Id
    private String id;

    private String playerName;
    private int jerseyNumber;
    private String position;
    private String teamName;

    public Player() {
    }

    public Player(String id, String playerName, int jerseyNumber,
                  String position, String teamName) {
        this.id = id;
        this.playerName = playerName;
        this.jerseyNumber = jerseyNumber;
        this.position = position;
        this.teamName = teamName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getJerseyNumber() {
        return jerseyNumber;
    }

    public void setJerseyNumber(int jerseyNumber) {
        this.jerseyNumber = jerseyNumber;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    @Override
public String toString() {
    return "Player{" +
            "id='" + id + '\'' +
            ", playerName='" + playerName + '\'' +
            ", teamName='" + teamName + '\'' +
            ", position='" + position + '\'' +
            ", jerseyNumber=" + jerseyNumber +
            '}';
}
}