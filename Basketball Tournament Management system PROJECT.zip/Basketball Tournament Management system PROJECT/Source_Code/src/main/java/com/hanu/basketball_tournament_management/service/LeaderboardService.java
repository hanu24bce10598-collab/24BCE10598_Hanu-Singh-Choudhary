package com.hanu.basketball_tournament_management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanu.basketball_tournament_management.model.Leaderboard;
import com.hanu.basketball_tournament_management.repository.LeaderboardRepository;

@Service
public class LeaderboardService {

    @Autowired
    private LeaderboardRepository leaderboardRepository;

    public Leaderboard saveLeaderboard(Leaderboard leaderboard) {
        return leaderboardRepository.save(leaderboard);
    }

    public List<Leaderboard> getAllLeaderboards() {
        return leaderboardRepository.findAll();
    }

    public Leaderboard getLeaderboardById(String id) {
        return leaderboardRepository.findById(id).orElse(null);
    }

    public Leaderboard updateLeaderboard(String id, Leaderboard leaderboard) {

        Leaderboard existingLeaderboard =
                leaderboardRepository.findById(id).orElse(null);

        if (existingLeaderboard != null) {

            existingLeaderboard.setTeamName(leaderboard.getTeamName());
            existingLeaderboard.setWins(leaderboard.getWins());
            existingLeaderboard.setLosses(leaderboard.getLosses());
            existingLeaderboard.setPoints(leaderboard.getPoints());

            return leaderboardRepository.save(existingLeaderboard);
        }

        return null;
    }

    public void deleteLeaderboard(String id) {
        leaderboardRepository.deleteById(id);
    }
}