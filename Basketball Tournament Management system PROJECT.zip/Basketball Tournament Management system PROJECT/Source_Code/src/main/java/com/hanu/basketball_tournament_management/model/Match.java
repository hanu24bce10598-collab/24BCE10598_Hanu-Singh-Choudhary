package com.hanu.basketball_tournament_management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "matches")
public class Match {

    @Id
    private String id;

    private String team1;
    private String team2;
    private int score1;
    private int score2;
    private String winner;

    public Match() {
    }

    public Match(String id, String team1, String team2,
                 int score1, int score2, String winner) {
        this.id = id;
        this.team1 = team1;
        this.team2 = team2;
        this.score1 = score1;
        this.score2 = score2;
        this.winner = winner;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeam1() {
        return team1;
    }

    public void setTeam1(String team1) {
        this.team1 = team1;
    }

    public String getTeam2() {
        return team2;
    }

    public void setTeam2(String team2) {
        this.team2 = team2;
    }

    public int getScore1() {
        return score1;
    }

    public void setScore1(int score1) {
        this.score1 = score1;
    }

    public int getScore2() {
        return score2;
    }

    public void setScore2(int score2) {
        this.score2 = score2;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }

    @Override
public String toString() {
    return "Match{" +
            "id='" + id + '\'' +
            ", team1='" + team1 + '\'' +
            ", team2='" + team2 + '\'' +
            ", score1=" + score1 +
            ", score2=" + score2 +
            ", winner='" + winner + '\'' +
            '}';
}
}