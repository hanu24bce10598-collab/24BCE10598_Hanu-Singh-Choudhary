Basketball Tournament Management System

Introduction

The Basketball Tournament Management System is a Spring Boot and MongoDB based application developed to manage basketball tournaments efficiently. The system provides functionalities for managing teams, players, matches, and leaderboards through REST APIs as well as a console-based interface.

The project demonstrates the implementation of CRUD (Create, Read, Update, Delete) operations using Spring Boot, MongoDB, Maven, and Postman.

---

Objectives

- Manage basketball teams and player information.
- Record match details and results.
- Maintain tournament leaderboards.
- Perform complete CRUD operations.
- Store and retrieve data using MongoDB.
- Provide both REST API and Console-Based access.

---

Technologies Used

Backend

- Java 21
- Spring Boot
- Spring Data MongoDB
- Maven

Database

- MongoDB
- MongoDB Compass

Testing Tools

- Postman

Development Environment

- Visual Studio Code (VS Code)

---

Project Architecture

Controller Layer
        ↓
Service Layer
        ↓
Repository Layer
        ↓
MongoDB Database

---

Modules Implemented

Team Management

- Add Team
- View Team
- Update Team
- Delete Team

Player Management

- Add Player
- View Player
- Update Player
- Delete Player

Match Management

- Add Match
- View Match
- Update Match
- Delete Match

Leaderboard Management

- Add Leaderboard Entry
- View Leaderboard
- Update Leaderboard
- Delete Leaderboard Entry

---

REST API Endpoints

Teams

- POST /teams
- GET /teams
- GET /teams/{id}
- PUT /teams/{id}
- DELETE /teams/{id}

Players

- POST /players
- GET /players
- GET /players/{id}
- PUT /players/{id}
- DELETE /players/{id}

Matches

- POST /matches
- GET /matches
- GET /matches/{id}
- PUT /matches/{id}
- DELETE /matches/{id}

Leaderboards

- POST /leaderboards
- GET /leaderboards
- GET /leaderboards/{id}
- PUT /leaderboards/{id}
- DELETE /leaderboards/{id}

---

MongoDB Collections

The application uses the following collections:

- teams
- players
- matches
- leaderboard

---

Features

- Full CRUD Operations
- MongoDB Integration
- RESTful API Architecture
- Console-Based Menu
- NBA Sample Dataset
- Postman API Testing
- Real-Time Data Storage and Retrieval

---

Future Enhancements

- Tournament Scheduling Module
- Player Statistics Tracking
- Team Ranking Automation
- Authentication and Authorization
- Web-Based User Interface

---

Author

Hanu Singh Choudhary
